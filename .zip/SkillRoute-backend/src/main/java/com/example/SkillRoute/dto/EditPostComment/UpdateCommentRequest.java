package com.example.SkillRoute.dto.EditPostComment;

import lombok.Data;

@Data
public class UpdateCommentRequest {
    private String text;
}

