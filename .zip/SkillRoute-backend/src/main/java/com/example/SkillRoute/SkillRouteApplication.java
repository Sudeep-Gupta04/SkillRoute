package com.example.SkillRoute;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SkillRouteApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillRouteApplication.class, args);
	}

}
