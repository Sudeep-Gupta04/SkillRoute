package com.example.SkillRoute.dto.EditPostComment;

import lombok.Data;

@Data
public class UpdatePostRequest {
    private String title;
    private String content;
}
