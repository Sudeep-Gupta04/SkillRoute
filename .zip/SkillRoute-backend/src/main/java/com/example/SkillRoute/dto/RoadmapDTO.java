package com.example.SkillRoute.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class RoadmapDTO {
    private String title;
}