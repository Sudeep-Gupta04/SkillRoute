package com.example.SkillRoute.model.Blog;

public enum VoteType {
    UPVOTE, DOWNVOTE
}