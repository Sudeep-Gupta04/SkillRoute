package com.example.SkillRoute;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillRouteApplicationTests {

	@Test
	void contextLoads() {
	}

}
